UnityShooterStarter (Scripts Only)

How to use:
1) Create a new Unity 2021+ 3D (URP/Standard) project.
2) Copy 'Assets/Scripts' into your project's Assets.
3) In a new Scene:
   - Add a Plane/Cube floor.
   - Create Player (Capsule + CharacterController) and add:
       Player/PlayerMotor, Player/PlayerLook, Combat/HitscanWeapon, Combat/Recoil
       Assign a Camera as a child to the player and reference it in PlayerLook & Recoil.
   - Add Combat/GrenadeSpawner and link your grenade prefabs.
   - Add Teams/TeamManager and set materials.
   - (Optional) Drop Modes/DeathmatchMode and set spawn points.
   - For bots: Add a NavMeshAgent + AI/BotController + AI/BotShooter and bake NavMesh.
4) Create weapon prefabs using Combat/HitscanWeapon or Extra/Weapon + Extra/PlayerShooting.
5) Press Play.

Note: This package includes scripts only. You need to create/assign prefabs and FX in Unity.
