public enum Team { Terrorists, CounterTerrorists }
