using UnityEngine;

public class PlantTheBombMode : MonoBehaviour {
    public Bomb bombPrefab; public BombSite siteA, siteB;
    public float defuseTime = 5f;
}
