using UnityEngine;

public class BombSite : MonoBehaviour { public string label = "A"; }
