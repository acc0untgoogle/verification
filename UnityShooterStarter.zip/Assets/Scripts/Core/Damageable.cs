using UnityEngine;

public interface IDamageable {
    void TakeDamage(float dmg, GameObject instigator = null);
}
